export { default } from "./my/ChurchBadge";
export { default as ChurchBadge } from "./my/ChurchBadge";
