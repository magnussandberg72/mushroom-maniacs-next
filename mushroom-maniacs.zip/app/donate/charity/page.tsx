// Path: app/donate/charity/page.tsx
export default function CharityPage() {
  return (
      <div className="p-6">
            <h1 className="text-2xl font-bold">Charity</h1>
                  <p>Lista över välgörenhetsprojekt kommer här.</p>
                      </div>
                        );
                        }
